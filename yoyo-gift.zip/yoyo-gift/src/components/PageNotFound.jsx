import React from 'react';

const PageNotFound = () => <h2>Oops! There is no page found.</h2>;

export default PageNotFound;
