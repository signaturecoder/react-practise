export default {
  vendors: [],
  users: [],
};
